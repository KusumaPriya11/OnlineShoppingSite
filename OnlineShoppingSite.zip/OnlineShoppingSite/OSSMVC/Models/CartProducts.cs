﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OSSMVC.Models
{
    public class CartProducts
    {
        /// <summary>
        /// These are the properties of cart products
        /// </summary>
        public int Quantity { get; set; }
        public int ProductId { get; set; }
        public string Picture { get; set; }
        public string Brand { get; set; }
        public double Price { get; set; }
        public string Content { get; set; }
        //Here we are splitting the content using the comma(,) first and later using colon(:)
        public string DisplayContent()
        {
            string data = null;
            string[] col = Content.Split(',');
            foreach (var item in col)
            {
                string colName, colValue;
                string[] cols = item.Split(':');
                colName = cols[0];
                colValue = cols[1];
                data += "<b>" + colName + "</b>" + " : " + colValue + "<br/></br>";
            }
            return data;
        }
    }
}