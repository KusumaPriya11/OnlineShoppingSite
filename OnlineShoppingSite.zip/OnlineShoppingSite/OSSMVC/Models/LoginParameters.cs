﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OSSMVC.Models
{
    public class LoginParameters
    {
        [Required(ErrorMessage ="UserName is must")]
        [StringLength (20,MinimumLength =5,ErrorMessage ="UserName should be between 5-20 characters")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Password is must")]
        [StringLength(20, MinimumLength =7, ErrorMessage ="Password should be between 5-20 characters")]
        public string Password { get; set; }
        public string MailId { get; set; }
        //public string ConfirmPassword { get; set; }
    }
}