﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Newtonsoft.Json;
using OSSMVC.Models;

namespace OSSMVC.Controllers
{
    public class SecurityController : Controller
    {
        // GET: Security
        [HttpGet]
        public ActionResult Login()
        {
            var returnUrl = Request.QueryString.Get("ReturnUrl");
            ViewData.Add("returnUrl", returnUrl);
            return View();
        }
        [HttpPost]
        public ActionResult Login(LoginParameters p)
        {
            Uri uri = new Uri("http://localhost:62669/api/Security/");
            using (var client=new HttpClient())
            {
                client.BaseAddress = uri;
                //var result = client.GetStringAsync("GetLogin/"+p.UserName+"/"+p.Password).Result;
                //var lp = JsonConvert.DeserializeObject<LoginParameters>(result);
                var uname = client.GetStringAsync("GetUserName/" + p.UserName).Result;
                var name = JsonConvert.DeserializeObject<LoginParameters>(uname);
                string username = name.UserName;

                var password = client.GetStringAsync("GetPassword/" + p.Password).Result;
                var pass = JsonConvert.DeserializeObject<LoginParameters>(password);
                string pwd = pass.Password;
                if (p.UserName.Equals(username) && p.Password.Equals(pwd))
                {
                    FormsAuthentication.SetAuthCookie(p.UserName,false);
                    var returnurl = Request.Form["returnUrl"];
                    return Redirect(returnurl);
                }
                else
                {
                    ModelState.AddModelError("UserName","UserName & Password are invalid");
                }
                var returnUrl = Request.QueryString.Get("ReturnUrl");
                ViewData.Add("returnurl",returnUrl);
                return View();
            }
        }
        [HttpPost]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return View();
        }
    }
}