﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using Newtonsoft.Json;
using OSSMVC.Models;


namespace OSSMVC.Controllers
{
    public class OSSController : Controller
    {
        Uri uri = new Uri("http://localhost:62669/api/OSS/");
        /// <summary>
        ///  To display index page
        /// </summary>
        /// <returns>Index view</returns>
        [HttpGet]
        public ActionResult Index()
        {
            using (var client=new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.DeleteAsync("DeleteCartItems").Result;
            }
            return View();
        }
        /// <summary>
        /// Display list or item based on the entered data(name)
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Display(string Name)
        {
            using (var client=new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("GetAllByName/" + Name).Result;
                var lst = JsonConvert.DeserializeObject<List<ProductDetails>>(result);
                return View(lst);
            }    
        }
        /// <summary>
        /// To view the data of particular item in the list(based on id)
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Return display details view</returns>
        [HttpGet]
        public ActionResult DisplayDetails(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("GetById/" + id).Result;
                var pd = JsonConvert.DeserializeObject<ProductDetails>(result);
                return View(pd);
            }
        }
        [HttpGet]
        public ActionResult AddToWishList()
        {
            return View();
        }
        /// <summary>
        /// To make list of selected items
        /// </summary>
        /// <param name="p"></param>
        /// <returns>returns the display details view based on the p.ProductId</returns>
        [HttpPost]
        public ActionResult AddToWishList(CartProducts p)
        {
              var lst = new List<CartProducts>();

            if (Session["Cart"] == null)
            {
               // List<CartProducts> lst = new List<CartProducts>();
                lst.Add(p);
                Session.Add("Cart", lst);
            }
            else
            {
                lst = (List<CartProducts>)Session["Cart"];
                var cp = lst.Where(o => o.ProductId == p.ProductId).SingleOrDefault();
                if (cp == null)
                {
                    lst.Add(p);
                    Session.Add("Cart", lst);
                }
                else
                {
                    TempData.Add("Exist","Item is already added");
                }
               
            }
            return RedirectToAction("DisplayDetails",new { id=p.ProductId});
        }
        /// <summary>
        /// Display the items in the wishlist
        /// </summary>
        /// <returns>returns the view of wishlist</returns>
        [HttpGet]
        public ActionResult DisplayWishList()
        {
            var lst = (List<CartProducts>)Session["Cart"];
            Session.Add("Cart1", lst);
            return View(lst);
        }
        /// <summary>
        /// To sent the selected items to the cart
        /// </summary>
        /// <returns></returns>
        public ActionResult PostToCart()
        {
            var lst = (List<CartProducts>)Session["Cart1"];
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync<List<CartProducts>>("AddToCart", lst).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "edit your order");
                }
                else
                {
                    ViewData.Add("msg", "visit later,Something went wrong,Sorry for Inconvience");
                }
                return View();
            }
        }
        /// <summary>
        /// To retrieve the data from the database
        /// </summary>
        /// <returns>Returns the view getfromcart</returns>
        public ActionResult GetFromCart()
        {
           using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("GetFromCart").Result;
                var lst = JsonConvert.DeserializeObject<List<CartProducts>>(result);
                return View(lst);
            }
        }
        /// <summary>
        /// To delete the data from the databse
        /// </summary>
        /// <param name="id"></param>
        /// <returns>returns the view getfromcart</returns>
        public ActionResult DeleteById(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.DeleteAsync("DeleteById/" + id).Result;
                if (TempData["msg"] != null)
                {
                    TempData.Remove("msg");
                }
                if (result.IsSuccessStatusCode == true)
                {
                    TempData.Add("msg", "Item is Deleted");
                }
                else
                {
                    TempData.Add("msg", "Item is not Deleted");
                }
            }
            return RedirectToAction("GetFromCart");
        }
        /// <summary>
        /// to get the details by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult PutQuantityById(int id)
        {
            using (var client=new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("GetQuantityById/" + id).Result;
                var cartproduct =JsonConvert.DeserializeObject<CartProducts>(result);
                return View(cartproduct);
            }
        }
        /// <summary>
        /// To update the quantity
        /// </summary>
        /// <param name="cartproduct"></param>
        /// <returns>returns the view get from cart</returns>
        [HttpPost]
        public ActionResult PutQuantityById(CartProducts cartproduct)
        {
            using (var client=new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.PutAsJsonAsync("PutQuantityById/" + cartproduct.ProductId, cartproduct).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    TempData.Add("msg", "Quantity is updated");
                }
                else
                {
                    TempData.Add("msg", "Sorry quantity is not updated");
                }
            }
            return RedirectToAction("GetFromCart");
        }
        /// <summary>
        /// To remove all the data from the session
        /// </summary>
        /// <returns>returns the view order</returns>
        [Authorize]
        public ActionResult Order()
        {
            Session.Remove("Cart");
            return View();
        }
    }
}