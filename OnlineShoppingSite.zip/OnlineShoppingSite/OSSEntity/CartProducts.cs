﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSSEntity
{
    public class CartProducts
    {
        /// <summary>
        /// Thse are the properties if cart products
        /// </summary>
        public int Quantity { get; set; }
        public int ProductId { get; set; }
        public string Picture { get; set; }
        public string Brand { get; set; }
        public double Price { get; set; }
        public string Content { get; set; }
        public string DisplayContent()
        {
            string data = null;
            string[] col = Content.Split(',');
            foreach (var item in col)
            {
                string colName, colValue;
                string[] cols = item.Split(':');
                colName = cols[0];
                colValue = cols[1];
                data += "<b>" + colName + "</b>" + " : " + colValue + "<br/></br>";
            }
            return data;
        }
    }
}
