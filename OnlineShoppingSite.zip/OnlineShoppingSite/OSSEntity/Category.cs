﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSSEntity
{
    public class Category
    {
        /// <summary>
        /// These are the properties of the category table
        /// </summary>
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
