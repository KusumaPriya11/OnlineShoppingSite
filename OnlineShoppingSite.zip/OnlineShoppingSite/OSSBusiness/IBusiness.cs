﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OSSEntity;
using OSSDataAccess;

namespace OSSBusiness
{
    interface IBusiness
    {
        List<ProductDetails> GetAllByName(string CategoryName);
        ProductDetails GetDetailsById(int id);
        void PostToCart(List<CartProducts> lst);
        List<CartProducts> GetFromCart();
        void DeleteById(int id);
        CartProducts GetQuantityById(int id);
        void UpdateQuantityById(CartProducts cp);
        void DeleteCartItems();
        string GetUserName(string name);
        string GetPassword(string password);

    }
}
