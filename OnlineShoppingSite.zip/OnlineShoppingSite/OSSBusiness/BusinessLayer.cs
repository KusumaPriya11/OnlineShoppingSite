﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OSSEntity;
using OSSErrorHandling;
using OSSDataAccess;

namespace OSSBusiness
{
    public class BusinessLayer : IBusiness
    {
        /// <summary>
        /// Now differentiate Name based on Category(like clothing,Accessories etc...),
        ///Product type(like shirts, watches etc..) and based on Brands(like nike, Fastrack etc..).
        /// </summary>
        /// <param name="Name"></param>
        /// <returns>List of productdetails</returns>

        public List<ProductDetails> GetAllByName(string Name)
        {
            try
            {
                DataAccess da = new DataAccess();
                var lstpd = da.GetAllByCategoryName(Name);
                //If the entered Name is one of the category type then we can get the list based on that.
                if (lstpd.Count != 0)
                {
                    return lstpd;
                }
                // Otherwise list will come to else part(Here it will check both product type and brand name )
                else
                {
                    var lst = da.GetAllByBrandNameOrProductType(Name);
                    return lst;
                }
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
        }
        /// <summary>
        /// Here it wil display product details based on the product id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Returns the details of the product based on thr id</returns>
        public ProductDetails GetDetailsById(int id)
        {
            try
            {
                DataAccess da = new DataAccess();
                var pd = da.GetDetailsById(id);
                return pd;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
        /// <summary>
        /// here we are passing the ordered products(cart products) to the cartproducts table
        /// </summary>
        /// <param name="lst">list of product details</param>

        public void PostToCart(List<CartProducts> lst)
        {
            try
            {
                DataAccess da = new DataAccess();
                da.PostToCart(lst);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
        }
        /// <summary>
        /// here we are retriveing data from the database(for editing purpose)
        /// </summary>
        /// <returns>List of product Details</returns>
        public List<CartProducts> GetFromCart()
        {
            try
            {
                DataAccess da = new DataAccess();
                var lst = da.GetFromCart();
                return lst;
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
        }
        /// <summary>
        ///  Deleting data from the cart
        /// </summary>
        /// <param name="id">passing productid</param>
        public void DeleteById(int id)
        {
            DataAccess da = new DataAccess();
            da.DeleteById(id);
        }
        /// <summary>
        /// Get the product based on id(from CartProducts table)
        /// </summary>
        /// <param name="id">passing id</param>
        /// <returns>Cart product</returns>
        public CartProducts GetQuantityById(int id)
        {
            DataAccess da = new DataAccess();
            var cp = da.GetQuantityById(id);
            return cp;
        }
        /// <summary>
        /// update using id
        /// </summary>
        /// <param name="cp"></param>
        public void UpdateQuantityById(CartProducts cp)
        {
            DataAccess da = new DataAccess();
            da.UpdateQuantityById(cp);
        }
        /// <summary>
        /// Delete all items from cart(cartproducts table)
        /// </summary>
        public void DeleteCartItems()
        {
            DataAccess b = new DataAccess();
            b.DeleteCartItems();
        }
        /// <summary>
        /// For login username
        /// </summary>
        /// <param name="name"></param>
        /// <param name="password"></param>
        /// <returns>returns loginparameters(UserName)</returns>
        
        public string GetUserName(string name)
        {
            DataAccess da = new DataAccess();
            var UserName = da.GetUserName(name);
            return UserName;
        }
        /// <summary>
        ///To check password
        /// </summary>
        /// <param name="password"></param>
        /// <returns>return password</returns>
        public string GetPassword(string password)
        {
            DataAccess da = new DataAccess();
            var Password = da.GetUserName(password);
            return Password;
        }
    }

}
