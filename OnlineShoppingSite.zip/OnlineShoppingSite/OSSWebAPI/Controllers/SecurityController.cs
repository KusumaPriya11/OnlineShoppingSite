﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OSSEntity;
using OSSBusiness;

namespace OSSWebAPI.Controllers
{
    public class SecurityController : ApiController
    {
        [Route("api/Security/GetUserName/{name}")]
        public string GetUserName(string name)
        {
            BusinessLayer b = new BusinessLayer();
            var UserName = b.GetUserName(name);
            return UserName;
        }
        [Route("api/Security/GetPassword/{password}")]
        public string GetPassword(string password)
        {
            BusinessLayer b = new BusinessLayer();
            var Password = b.GetPassword(password);
            return Password;
        }
    }
}
