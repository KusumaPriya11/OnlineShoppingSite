﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OSSEntity;
using OSSBusiness;
using OSSErrorHandling;

namespace OSSWebAPI.Controllers
{
    public class OSSController : ApiController
    {
        /// <summary>
        ///  To get any product details based on the name
        /// </summary>
        /// <param name="Name"></param>
        /// <returns>list of product details</returns>
        [Route("api/OSS/GetAllByName/{Name}")]
        public HttpResponseMessage GetAllByName(string Name)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                BusinessLayer b = new BusinessLayer();
                var lstpd = b.GetAllByName(Name);
                msg= Request.CreateResponse<List<ProductDetails>>(lstpd);
            }
            catch (OSSException ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch 
            {
                msg = Request.CreateResponse(HttpStatusCode.NotFound, "No item that match with the name");
            }
            return msg;
        }
        /// <summary>
        /// To get product details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>product details</returns>
        [Route("api/OSS/GetById/{id}")]
        public HttpResponseMessage GetById(int id)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                BusinessLayer b = new BusinessLayer();
                var pd = b.GetDetailsById(id);
                msg = Request.CreateResponse<ProductDetails>(pd);
            }
            catch (OSSException ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch 
            {
                msg = Request.CreateResponse(HttpStatusCode.NotFound, "No id that match with the name");
            }
            return msg;
        }
       [Route("api/OSS/AddToCart")]
        public HttpResponseMessage Post([FromBody] List<CartProducts> lst)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK, "All items are added to cart");
            try
            {
                BusinessLayer b = new BusinessLayer();
                b.PostToCart(lst);
            }
            catch (OSSException ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.NotFound, ex.Message);
            }
            return msg;
        }
        [Route("api/OSS/GetFromCart")]
        public HttpResponseMessage GetFromCart()
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK, "Record is deleted");
            try
            {
                BusinessLayer b = new BusinessLayer();
                var pd = b.GetFromCart();
                msg = Request.CreateResponse<List<CartProducts>>(pd);
            }
            catch (OSSException ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.NotFound, ex.Message);
            }
            return msg;
        }
        [Route("api/OSS/DeleteById/{id}")]
        public HttpResponseMessage DeleteById(int id)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK,"Record is deleted");
            try
            {
                BusinessLayer b = new BusinessLayer();
                b.DeleteById(id);
            }
            catch(OSSException ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch(Exception ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.NotFound, ex.Message);
            }
            return msg;
        }
        [Route("api/OSS/GetQuantityById/{id}")]
        public HttpResponseMessage GetQuantityById(int id)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                BusinessLayer b = new BusinessLayer();
                var cp = b.GetQuantityById(id);
                msg = Request.CreateResponse<CartProducts>(cp);
            }
            catch (OSSException ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.NotFound, ex.Message);
            }
            return msg;

        }
        [Route("api/OSS/PutQuantityById/{id}")]
        public HttpResponseMessage PutQuantityById([FromBody]CartProducts cp,int id)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK, "Record is updated");
            try
            {
                cp.ProductId = id;
                BusinessLayer b = new BusinessLayer();
                b.UpdateQuantityById(cp);
            }
            catch (OSSException ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.NotFound, ex.Message);
            }
            return msg;
        }
        [Route("api/OSS/DeleteCartItems")]
        public HttpResponseMessage DeleteCartItems()
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK, "All cart items are deleted");
            try
            {
                BusinessLayer b = new BusinessLayer();
                b.DeleteCartItems();
            }
            catch (OSSException ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch(Exception ex)
            {
                msg = Request.CreateResponse(HttpStatusCode.NotFound,ex.Message);
            }
            return msg;
        }
    }
}
