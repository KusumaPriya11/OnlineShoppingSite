﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OSSEntity;
using OSSErrorHandling;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace OSSDataAccess
{
    public class DataAccess : IDataAccess
    {
        //object creation for connection and command
        SqlConnection con;
        SqlCommand cmd;
        public DataAccess()
        {
            //  //Creating instance for connection
            con = new SqlConnection();
            //attaching connection to database using connection string
            con.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString;
        }
        /// <summary>
        /// Display the list of items from productDetails table based on the category name(by matching the category id)
        /// </summary>
        /// <param name="CategoryName"></param>
        /// <returns>List of productsDetails</returns>
        public List<ProductDetails> GetAllByCategoryName(string CategoryName)
        {
            try
            {
                //creating the list of product details
                List<ProductDetails> lstpd = new List<ProductDetails>();
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = "select p.Picture,p.Brand,p.Content,p.Price,p.ProductId ,c.CategoryId from ProductDetails as p ,Category as c" +
                                  " where p.CategoryId = c.CategoryId and" +
                                  " c.CategoryId = (select CategoryId from Category where CategoryName like @cat)";
                cmd.Parameters.AddWithValue("@cat", CategoryName+"%");
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //Opening connection
                con.Open();
                //Executing the command
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    ProductDetails pd = new ProductDetails
                    {
                        Picture = sdr[0].ToString(),
                        Brand = sdr[1].ToString(),
                        Content = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3]),
                        ProductId = (int)sdr[4],
                        CategoryId = (int)sdr[5]
                    };
                    lstpd.Add(pd);
                }
                return lstpd;
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// Here if the name matches for brand name or product type then the data will pass to business layers
        /// </summary>
        /// <param name="Name"></param>
        /// <returns>List of product details</returns>
        public List<ProductDetails> GetAllByBrandNameOrProductType(string Name)
        {
            try
            {
                List<ProductDetails> lstpd = new List<ProductDetails>();
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = " select Picture,Brand,Content,Price,ProductId,CategoryId from ProductDetails where  Brand=@b or ProductType like @b1  ";
                cmd.Parameters.AddWithValue("@b1",Name+"%");
                cmd.Parameters.AddWithValue("@b",Name);
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //Opening connection
                con.Open();
                //Executing the command
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    ProductDetails pd = new ProductDetails
                    {
                        Picture = sdr[0].ToString(),
                        Brand = sdr[1].ToString(),
                        Content = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3]),
                        ProductId = (int)sdr[4],
                        CategoryId = (int)sdr[5]
                    };
                    lstpd.Add(pd);
                }
                return lstpd;
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// Get details based on the productid
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Details based on the id(from the table productdetails)</returns>
        public ProductDetails GetDetailsById(int id)
        {
            try
            {
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = "select Picture,Brand,Content,Price from ProductDetails where ProductId=@id";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //Opening connection
                con.Open();
                //Executing the command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    ProductDetails pd = new ProductDetails
                    {
                        Picture = sdr[0].ToString(),
                        Brand = sdr[1].ToString(),
                        Content = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3]),
                        ProductId = id,
                    };
                    return pd;
                }
                else
                {
                    throw new Exception("No records based on this id");
                }
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// To post all the data to the table cartproducts
        /// </summary>
        /// <param name="lst"></param>
        public void PostToCart(List<CartProducts> lst)
        {
            try
            {
                //Opening connection(as we are opening loop ,we opened connection here)
                con.Open();
                foreach (var p in lst)
                {
                    //Creating instance for command
                    cmd = new SqlCommand();
                    cmd.CommandText = "insert into CartProducts(Brand,Price,Picture,Content,ProductId) values(@b,@p,@pic,@c,@pid)";
                    cmd.Parameters.AddWithValue("@b", p.Brand);
                    cmd.Parameters.AddWithValue("@p", p.Price);
                    cmd.Parameters.AddWithValue("@pic", p.Picture);
                    cmd.Parameters.AddWithValue("@c", p.Content);
                    cmd.Parameters.AddWithValue("@pid", p.ProductId);
                    cmd.CommandType = System.Data.CommandType.Text;
                    //Attach connection with the command
                    cmd.Connection = con;
                    //Executing the command
                    int eff = cmd.ExecuteNonQuery();
                    if (eff == 0)
                    {
                        throw new Exception("Could not add data");
                    }
                }
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// Get all from cartProducts
        /// </summary>
        /// <returns>List of the cartproducts from the table cartproducts</returns>
        public List<CartProducts> GetFromCart()
        {
            try
            {
                List<CartProducts> lstpd = new List<CartProducts>();
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = " select Picture,Brand,Content,Price,ProductId,Quantity from CartProducts";
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //Opening connection
                con.Open();
                //Executing the command
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    CartProducts pd = new CartProducts
                    {
                        Picture = sdr[0].ToString(),
                        Brand = sdr[1].ToString(),
                        Content = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3]),
                        ProductId = (int)sdr[4],
                        Quantity=(int)sdr[5]
                    };
                    lstpd.Add(pd);
                }
                return lstpd;
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// Delete the record based on the id(from the CartProducts table)
        /// </summary>
        /// <param name="id">id</param>
        public void DeleteById(int id)
        {
            try 
            {
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = "delete from CartProducts where ProductId=@id";
                cmd.Parameters.AddWithValue("@id",id);
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //Opening connection
                con.Open();
                //Executing the command
                int eff = cmd.ExecuteNonQuery();
                if (eff == 0)
                {
                    throw new Exception("Could not delete data");
                }
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// getting values by id
        /// </summary>
        /// <param name="id">id</param>
        /// <returns>Details of that particular id</returns>
        public CartProducts GetQuantityById(int id)
        {
            try
            {
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = "select Picture,Brand,Content,Price,Quantity from CartProducts where ProductId=@id";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //Opening connection
                con.Open();
                //Executing the command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    CartProducts cp = new CartProducts
                    {
                        Picture = sdr[0].ToString(),
                        Brand = sdr[1].ToString(),
                        Content = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3]),
                        ProductId = id,
                        Quantity = (int)sdr[4]
                    };
                    return cp;
                }
                else
                {
                    throw new Exception("No record based on this id");
                }
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// Update the values based on the id(quantity updation in CartProducts table)
        /// </summary>
        /// <param name="cp"></param>
        public void UpdateQuantityById(CartProducts cp)
        {
            try
            {
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = "Update CartProducts set Quantity=@q where ProductId=@id";
                cmd.Parameters.AddWithValue("@id",cp.ProductId );
                cmd.Parameters.AddWithValue("@q", cp.Quantity);
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //opening connection
                con.Open();
                //Executing the command
                int eff = cmd.ExecuteNonQuery();
                if (eff==0)
                {
                    throw new Exception("Quantity is not updated");
                }
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// Deleting all item in the table CartProducts
        /// </summary>
        public void DeleteCartItems()
        {
            try
            {
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = "delete from CartProducts";
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //opening connection
                con.Open();
                //Executing the command
                int eff = cmd.ExecuteNonQuery();
                if (eff == 0)
                {
                    throw new Exception("Could not delete data");
                }
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
        }
        /// <summary>
        /// For login username
        /// </summary>
        /// <param name="name"></param>
        /// <param name="password"></param>
        /// <returns>returns loginparameters(UserName)</returns>
        public string GetUserName(string name)
        {
            LoginParameters lp = new LoginParameters();
            try
            {
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = "select UserName from LoginParameters where UserName=@name";
                cmd.Parameters.AddWithValue("@name", name);
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //Opening connection
                con.Open();
                //Executing the command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    lp.UserName = sdr[0].ToString();
                }
                else
                {
                    throw new Exception("No records based on this UserName&Password combination");
                }
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
            return lp.UserName;
        }
        /// <summary>
        ///To check password
        /// </summary>
        /// <param name="password"></param>
        /// <returns>return password</returns>
        public string GetPassword(string password)
        {
            LoginParameters lp = new LoginParameters();
            try
            {
                //Creating instance for command
                cmd = new SqlCommand();
                cmd.CommandText = "select Password from LoginParameters where Password=@password";
                cmd.Parameters.AddWithValue("@password", password);
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection with the command
                cmd.Connection = con;
                //Opening connection
                con.Open();
                //Executing the command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    lp.Password = sdr[0].ToString();
                }
                else
                {
                    throw new Exception("No records based on this UserName&Password combination");
                }
            }
            catch (SqlException e)
            {
                throw new OSSException(e.Message);
            }
            catch (Exception e)
            {
                throw new OSSException(e.Message);
            }
            finally
            {
                //Closing the connection
                con.Close();
            }
            return lp.Password;
        }
    }
}
