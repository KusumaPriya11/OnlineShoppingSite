﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OSSEntity;

namespace OSSDataAccess
{
    interface IDataAccess
    {
        List<ProductDetails> GetAllByCategoryName(string CategoryName);
        List<ProductDetails> GetAllByBrandNameOrProductType(string BrandName);
        ProductDetails GetDetailsById(int id);
        List<CartProducts> GetFromCart();
        void DeleteById(int id);
        CartProducts GetQuantityById(int id);
        void UpdateQuantityById(CartProducts cp);
        void DeleteCartItems();
        string GetUserName(string name);
        string GetPassword(string password);

    }
}
